# CHYPX Corporate Website

A responsive, static corporate website for the early-stage CHYPX semiconductor initiative.

## Preview locally
1. Extract this folder.
2. Open `index.html` in Firefox, Chrome or Edge.
3. Internet is only needed for the optional Google Fonts. The layout and content work without them.

## Publish free with Netlify
1. Open https://app.netlify.com/drop
2. Sign in or create a Netlify account.
3. Drag the entire `CHYPX_Corporate_Site` folder (or its extracted contents) onto the drop area.
4. Netlify will provide a temporary `*.netlify.app` website address.

## Before publishing
- Confirm that `https://www.instagram.com/chypx.official/` is the correct profile URL.
- Review the company wording and dates.
- The May 2028 date is presented as an establishment target, not a guarantee.
- This site intentionally does not claim that CHYPX already has a manufactured processor, lab, employees, investors or validated performance.
- Add a company email address only after it exists. Do not publish a personal email address.

## Files
- `index.html` — website content and page structure
- `styles.css` — responsive styling
- `script.js` — mobile navigation and current year
- `assets/chypx-mark.svg` — compact vector brand mark
